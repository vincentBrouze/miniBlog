-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mer 14 Février 2018 à 07:39
-- Version du serveur: 5.5.59-0ubuntu0.14.04.1
-- Version de PHP: 5.5.9-1ubuntu4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `MINIBLOG`
--

-- --------------------------------------------------------

--
-- Structure de la table `Article`
--

CREATE TABLE IF NOT EXISTS `Article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `dateCreation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `contenu` text NOT NULL,
  `idCategorie` int(11) NOT NULL,
  `idAuteur` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dateCreation` (`dateCreation`),
  KEY `idAuteur` (`idAuteur`),
  KEY `idCategorie` (`idCategorie`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Contenu de la table `Article`
--

INSERT INTO `Article` (`id`, `titre`, `description`, `logo`, `dateCreation`, `contenu`, `idCategorie`, `idAuteur`) VALUES
(1, 'Le tableau $_GET en php.', 'Un article pour expliquer comment transférer des données du client au serveur en PHP.', 'logos/icone-php.png', '2018-02-12 09:41:46', 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat', 1, 1),
(2, 'Les jointures', 'Explication sur les jointures SQL', 'logos/icone-sql.png', '2018-02-12 10:43:57', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 2, 2),
(9, 'LeTitre', 'description', 'logos/exo-terminal-emulator.desktop', '2018-02-12 14:11:01', 'Lorem ipsum...', 5, 2),
(11, 'L''événement load', 'Commment utiliser au mieux l''événement load.', 'logos/js.jpeg', '2018-02-12 14:31:08', 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat', 5, 3),
(13, 'letitre', 'ladesc', '', '2018-02-13 11:34:09', 'blahblajh', 3, 6),
(14, 'Les balises structurelles', 'Aucune', '', '2018-02-13 11:40:54', 'blahblahblah', 3, 7),
(15, 'Encore', 'un article de plus sur CSS', '', '2018-02-13 11:41:44', 'le contenu', 3, 8),
(16, 'Les requetes insert into', 'Inserer des enregistrements dans une table', '', '2018-02-13 11:48:45', 'sql etc', 2, 9),
(17, 'HAVING en sql', 'Conditions sur les groupes : clause HAVING', '', '2018-02-13 11:50:55', 'blahblah', 2, 9),
(18, 'Sous-select scalaire', 'Utiliser un sous-select pour calculer une valeur', '', '2018-02-13 11:52:39', 'jklm', 3, 9);

-- --------------------------------------------------------

--
-- Structure de la table `Auteur`
--

CREATE TABLE IF NOT EXISTS `Auteur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `Auteur`
--

INSERT INTO `Auteur` (`id`, `nom`, `email`, `description`) VALUES
(1, 'vincent', 'vincent.atassi@gmail.com', 'Moi'),
(2, 'Nico', 'nico.quoi@mail.fr', 'Nicolas'),
(3, 'Gérard', 'gege.bouq@yahoo.fr', NULL),
(6, 'NouveauMoi', 'nouv@moi.com', NULL),
(7, 'Mr MDN', 'mdn@mozilla.org', NULL),
(8, 'moimoi', 'moi@moi.com', NULL),
(9, 'sql expert', 'sql@moi.com', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `Categorie`
--

CREATE TABLE IF NOT EXISTS `Categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `Categorie`
--

INSERT INTO `Categorie` (`id`, `nom`, `description`) VALUES
(1, 'PHP', 'Les articles sur le langage PHP.'),
(2, 'SQL', 'Les ressources sur SQL.'),
(3, 'CSS3', 'Des articles sur les techniques de CSS3'),
(4, 'HTML5', 'Tout sur HTML5'),
(5, 'JavaScript', 'Ressources utiles sur la programmation JavaScript.');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `Article`
--
ALTER TABLE `Article`
  ADD CONSTRAINT `Article_ibfk_1` FOREIGN KEY (`idCategorie`) REFERENCES `Categorie` (`id`),
  ADD CONSTRAINT `Article_ibfk_2` FOREIGN KEY (`idAuteur`) REFERENCES `Auteur` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
